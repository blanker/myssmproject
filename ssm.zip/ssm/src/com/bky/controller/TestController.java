package com.bky.controller;

public class TestController {
	
	public static void main(String[] args) {
		Double d = new Double("12.9");
		System.out.println(d);
	}

}
